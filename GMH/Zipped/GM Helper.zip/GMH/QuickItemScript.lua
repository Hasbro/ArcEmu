﻿function GmOutfit()
result=".character additem 2586"--Gamemaster's Robe
outSAY(result);
result=".character additem 11508"--Gamemaster's Slippers
outSAY(result);
result=".character additem 12064"--Gamemaster's Hood
outSAY(result);
result=".character additem 12947"--Alex's Ring of Audacity
outSAY(result);
result=".character additem 12947"--Alex's Ring of Audacity
outSAY(result);
result=".character additem 192"--Martin Thunder
outSAY(result);
result=".character additem 19879"--Alex's Test Beatdown Staff
outSAY(result);
result=".character additem 19160"--Contest Winner's Tabbard
outSAY(result);
result=".character additem 23162"--Foror's Crate of Endless Resist Gear Storage
outSAY(result);
result=".character additem 23162"--Foror's Crate of Endless Resist Gear Storage
outSAY(result);
result=".character additem 23162"--Foror's Crate of Endless Resist Gear Storage
outSAY(result);
result=".character additem 23162"--Foror's Crate of Endless Resist Gear Storage
outSAY(result);
end
--Gamemaster's Robe, Gamemaster's Slippers, Gamemaster's Hood, Alex's Ring of Audacity X2, Martin Thunder, Alex's Test Beatdown Staff, Contest Winner's Tabbard, Foror's Crate of Endless Resist Gear Storage X4

function MageT6()
result=".character additemset 671"
outSAY(result);
end

function HunterT6()
result=".character additemset 669"
outSAY(result);
end

function RogueT6()
result=".character additemset 668"
outSAY(result);
end

function WarlockT6()
result=".character additemset 670"
outSAY(result);
end

function WarriorT6()
result=".character additemset 673"
outSAY(result);
result=".character additemset 672"
outSAY(result);
end

function ShamanT6()
result=".character additemset 682"
outSAY(result);
result=".character additemset 683"
outSAY(result);
result=".character additemset 684"
outSAY(result);
end

function PriestT6()
result=".character additemset 674"
outSAY(result);
result=".character additemset 675"
outSAY(result);
end

function DruidT6()
result=".character additemset 676"
outSAY(result);
result=".character additemset 677"
outSAY(result);
result=".character additemset 678"
outSAY(result);
end

function PaladinT6()
result=".character additemset 679"
outSAY(result);
result=".character additemset 680"
outSAY(result);
result=".character additemset 681"
outSAY(result);
end
