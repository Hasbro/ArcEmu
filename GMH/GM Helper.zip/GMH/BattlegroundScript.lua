﻿function BGStart()
    result=".battleground startbg";
    outSAY(result);
end

function BGForceStart()
    result=".battleground forcestart";
    outSAY(result);
end

function BGInfo()
    result=".battleground bginfo";
    outSAY(result);
end

function BGLeave()
    result=".battleground leave"
    outSAY(result);
end
