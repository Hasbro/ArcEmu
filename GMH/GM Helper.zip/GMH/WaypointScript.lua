﻿function WaypointAdd()
    result=".waypoint add";
    outSAY(result);
end

function WaypointDel()
    result=".waypoint delete";
    outSAY(result);
end

function WaypointShow()
    result=".waypoint show";
    outSAY(result);
end

function WaypointHide()
    result=".waypoint hide";
    outSAY(result);
end
